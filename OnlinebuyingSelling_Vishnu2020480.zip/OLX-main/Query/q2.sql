select *
from description_table
where Short_description LIKE '%TVS%';