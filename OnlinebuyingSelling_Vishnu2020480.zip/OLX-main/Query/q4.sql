delete from product_table
where Product_Id = 54;
